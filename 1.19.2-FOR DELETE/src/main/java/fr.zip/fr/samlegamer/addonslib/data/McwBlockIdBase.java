package fr.samlegamer.addonslib.data;

import java.util.List;

public record McwBlockIdBase(String modid, List<BlockId> blocks) {
}