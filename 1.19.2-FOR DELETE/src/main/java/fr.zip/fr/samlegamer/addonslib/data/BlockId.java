package fr.samlegamer.addonslib.data;

public record BlockId(String id, String reflectedLocation) {
}